package com.rmv.array;

public class UserArray {

	public UserArray() {
		// TODO Auto-generated constructor stub
	}

}
