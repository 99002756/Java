module training1 {
}